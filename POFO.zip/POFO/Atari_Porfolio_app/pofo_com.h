

#ifndef POFO_COM
#define POFO_COM

#define ORDER_PING_POFODUINO		'A'
	



void 			Ping  		(void);




void 			InitPofoCom	(void);
void 			SendByte	(unsigned char byte);
unsigned char 	GetByte		(void);
char 			SendBuffer	(unsigned short Len, unsigned char *Buffer);
unsigned short 	GetBuffer	(unsigned char * Buffer);


#endif