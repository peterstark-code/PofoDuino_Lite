




 main()
{	
	InitPofoCom();		
	printf("wait connection\n");	
	PingPofoDuino();
	
	
	
	
}


