
#include <stdio.h>

#include "pofo_com.h"


#define PORT_OUTPUT 0x8078
#define PORT_INPUT  0x807A

#define PIN_CLOCK_INPUT 0x20



/***********************************************************************************/
#define MAX_BUFFER_SIZE 30

unsigned char Buffer[MAX_BUFFER_SIZE];

void PingPofoDuino()
{
	
	
	Buffer[0]= ORDER_PING_POFODUINO ;
	
	SendBuffer(1,Buffer);
	GetBuffer(Buffer);
	printf("%s\n",Buffer);
	
}




/*********************************************************************************/




void InitPofoCom (void)
{
	outport(0x8078,0);	
}


char SendBuffer(unsigned short Len, unsigned char *Buffer)
{
	
	unsigned short i						=	0;
	unsigned char CheckSum					=	0;
	unsigned char CheckSum_From_PofoDuino	=	0;
	
	SendByte((Len&0xFF00)>>8);
	SendByte(Len&0x00FF);
	
	
	for(i=0;i<Len;i++)
	{
		SendByte(Buffer	[i]);
		CheckSum+=Buffer[i];
	}
	
	SendByte(CheckSum);
	
	CheckSum_From_PofoDuino=GetByte();
	
	if(CheckSum==CheckSum_From_PofoDuino)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	
}


unsigned short GetBuffer(unsigned char * Buffer)
{
	
    unsigned short Len    = 0;
    unsigned char Byte_L  = 0;
    unsigned char CheckSum =0;
    unsigned char CheckSum_From_PofoDuino =0;
	unsigned short i=0;	
	
	Len = GetByte();
	Byte_L  = GetByte();
	

    Len =(Len<<8)|Byte_L; 
	
	
    for(i =0 ; i <Len;i++)
    {
      Buffer[i]=GetByte();
      CheckSum+=Buffer[i];
    }
    
    CheckSum_From_PofoDuino=GetByte();    
    SendByte(CheckSum);   

    if(CheckSum_From_PofoDuino==CheckSum)
    {
      return Len;
    }
    return 0;
}




unsigned char GetByte()
{
	/*synchronize*/
	unsigned char byte_H=0,tmp_byte= 0,byte_L=0,Final_byte=0;;
	
	
	
	outport(PORT_OUTPUT,0);
	
	while (!(inport(PORT_INPUT)&PIN_CLOCK_INPUT));				
	
	tmp_byte=inport(PORT_INPUT);
	byte_H 	= tmp_byte&0x03;
	byte_H |= (tmp_byte&0x18)>>1;
	byte_H <<=4;
	
	outport(PORT_OUTPUT,0x10);		
	
	while ((inport(PORT_INPUT)&PIN_CLOCK_INPUT));		
	outport(PORT_OUTPUT,0);
	while (!(inport(PORT_INPUT)&PIN_CLOCK_INPUT));
	
	tmp_byte=inport(PORT_INPUT);
	byte_L 	= tmp_byte&0x03;
	byte_L |= (tmp_byte&0x18)>>1;
	
	
	outport(PORT_OUTPUT,0x10);	
	while ((inport(PORT_INPUT)&PIN_CLOCK_INPUT));	
	outport(PORT_OUTPUT,0);
	
	
	Final_byte	=byte_H|byte_L;

	return Final_byte;		
}


void SendByte(unsigned char byte)
{
	/*synchronize*/
	unsigned char tmp_byte=(byte>>4)&0x0F;
	
	outport(PORT_OUTPUT,byte&0x0F);	
	
	while (!(inport(PORT_INPUT)&PIN_CLOCK_INPUT));	
	outport(PORT_OUTPUT,byte|0x10);		
	
	while ((inport(PORT_INPUT)&PIN_CLOCK_INPUT));		
	outport(PORT_OUTPUT,tmp_byte);		
	
	while (!(inport(PORT_INPUT)&PIN_CLOCK_INPUT));
	outport(PORT_OUTPUT,tmp_byte|0x10);	
	
	while ((inport(PORT_INPUT)&PIN_CLOCK_INPUT));
	outport(PORT_OUTPUT,tmp_byte);		
}