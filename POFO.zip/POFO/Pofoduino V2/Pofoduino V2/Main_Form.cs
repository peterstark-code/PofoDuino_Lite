﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pofoduino_V2
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void Button_Select_File_Click(object sender, EventArgs e)
        {
            OpenFileDialog MyFileDialogBox = new OpenFileDialog();
            MyFileDialogBox.Filter = "all file (*.*)|*.*";
            MyFileDialogBox.Multiselect = false;


            if (MyFileDialogBox.ShowDialog() == DialogResult.OK)
            {
                this.TextBox_File.Text = MyFileDialogBox.FileName;

            }
        }
        
        private bool CheckSerialPorts()
        {
            var names = SerialPort.GetPortNames();

            if (names.Length > 0)
            {
                this.ComboBox_SerialPort.Items.Clear();

                foreach (var name in names)
                {
                    this.ComboBox_SerialPort.Items.Add(name);
                }
                this.ComboBox_SerialPort.SelectedItem = names[0];

                return true;
            }




            return false;
        }

        private void Button_Send_Click(object sender, EventArgs e)
        {
            Pofoduino MyPofoDuino = new Pofoduino();

            if(MyPofoDuino.OpenPofoduino(this.ComboBox_SerialPort.Text,this.Label_Status))
            {

                this.Label_Status.Text = "uploading file";
                MyPofoDuino.SendFile(this.TextBox_File.Text, this.ProgressBar_upload, this.Label_Percent);


                MyPofoDuino.ClosePofoduino();
                this.Label_Status.Text = "Port Com closed";

                MessageBox.Show("File uploaded");

            }
            else
            {
                MessageBox.Show(" Please select a Port Com ");
            }

        }

        private void Main_Form_Load(object sender, EventArgs e)
        {
            CheckSerialPorts();
        }

       
    }
}
